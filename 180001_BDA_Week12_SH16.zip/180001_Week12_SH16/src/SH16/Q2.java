package SH16;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Q2 {
	
	private static String driverName = "org.apache.hive.jdbc.HiveDriver";
	private static Connection con = null;
	private static Statement stmt = null;
	
	 public static void main(String[] args) throws SQLException, ClassNotFoundException {
	      // Register driver and create driver instance
	   
	      Class.forName(driverName);
	      // get connection
	      
	      con = DriverManager.getConnection("jdbc:hive2://localhost:10000/default", "", "");
	      stmt = con.createStatement();
	      
	      //Load the data in olympic table
	      String load_oly = "load data local inpath '/home/cloudera/olympic_data.csv' overwrite into table Olympic_info";
	      System.out.println("Loading : "+ load_oly);
	      stmt.execute(load_oly);
	      
	      con.close();
	   }

}
