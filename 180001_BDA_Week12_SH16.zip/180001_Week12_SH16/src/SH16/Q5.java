package SH16;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Q5 {
	
	private static String driverName = "org.apache.hive.jdbc.HiveDriver";
	private static Connection con = null;
	private static Statement stmt = null;
	private static ResultSet rs = null;
	
	 public static void main(String[] args) throws SQLException, ClassNotFoundException {
	      // Register driver and create driver instance
	   
	      Class.forName(driverName);
	      // get connection
	      
	      con = DriverManager.getConnection("jdbc:hive2://localhost:10000/default", "", "");
	      stmt = con.createStatement();
	      
	      //total number of medals won by each country.
	      String total_medals = "select Country, sum(Total_medals) as Total from Olympic_info group by Country";
	      rs = stmt.executeQuery(total_medals);
	      
	      while(rs.next()){
	    	  System.out.println(rs.getString("Country")+ " " +rs.getInt("Total"));
	      }
	      
	      con.close();
	   }

}
