package SH16;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Q3 {
	
	private static String driverName = "org.apache.hive.jdbc.HiveDriver";
	private static Connection con = null;
	private static Statement stmt = null;
	
	 public static void main(String[] args) throws SQLException, ClassNotFoundException {
	      // Register driver and create driver instance
	   
	      Class.forName(driverName);
	      // get connection
	      
	      con = DriverManager.getConnection("jdbc:hive2://localhost:10000/default", "", "");
	      stmt = con.createStatement();
	      
	      //to create a partition table by year and load data into partition table from Olympic Table.
	      stmt.execute("CREATE TABLE olympic_part(AthleteName string, Age int, Country String, "
	         +" Closing_Date String, Sport String, Gold_medals int, Silver_medals int, Bronze_medals int,"
	         +"Total_medals int) partitioned by (Year int) row format delimited fields terminated by ','");
	      
	      stmt.execute("set hive.exec.dynamic.partition=true");
	      stmt.execute("set hive.exec.dynamic.partition.mode=nonstrict");
	      
	      String insert = "insert overwrite table olympic_part partition(Year) "
	    		  +"select AthleteName, Age, Country, Closing_Date, Sport, Gold_medals, "
	    		  +"Silver_medals, Bronze_medals, Total_medals, Year from olympic_info ";
	      
	      stmt.execute(insert);
	      
	      System.out.println("Partitioned table by year and loaded data into partitioned table from Olympic Table");
	      
	      con.close();
	   }

}
