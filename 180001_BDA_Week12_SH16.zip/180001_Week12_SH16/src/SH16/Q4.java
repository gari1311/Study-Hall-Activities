package SH16;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Q4 {
	
	private static String driverName = "org.apache.hive.jdbc.HiveDriver";
	private static Connection con = null;
	private static Statement stmt = null;
	
	 public static void main(String[] args) throws SQLException, ClassNotFoundException {
	      // Register driver and create driver instance
	   
	      Class.forName(driverName);
	      // get connection
	      
	      con = DriverManager.getConnection("jdbc:hive2://localhost:10000/default", "", "");
	      stmt = con.createStatement();
	      
	      //To create a bucket table by country and load data into partition table from Olympic Table.
	      stmt.execute("CREATE TABLE olympic_bucket(AthleteName string, Age int, Country String, Year int, "
	         +" Closing_Date String, Sport String, Gold_medals int, Silver_medals int, Bronze_medals int,"
	         +"Total_medals int) clustered by (Country) sorted by (Country) into 4 buckets");
	      
	      String insert = "insert overwrite table olympic_bucket select * from olympic_info ";
	      
	      stmt.execute(insert);
	      
	      System.out.println("Created a bucket table by country and loaded data into partitioned table from Olympic Table");
	      
	      con.close();
	   }

}
